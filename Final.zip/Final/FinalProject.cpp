#include <iostream>
#include <GL/glew.h>
#include <GL/freeglut.h>
#include <cstring>

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "SOIL2/SOIL2.h"
#include "SpoonPointImporter.h"

using namespace std;

#define WINDOW_TITLE "Modern OpenGL" // macro for window title

#ifndef GLSL
#define GLSL(Version, Source) "#version " #Version "\n" #Source
#endif

GLint shaderProgram, WindowWidth = 800, WindowHeight = 600;
GLuint VBO, VAO, EBO, texture;

GLfloat cameraSpeed = 0.0005f;

int mod_key;
GLfloat lastMouseX = 400, lastMouseY = 300;
GLfloat mouseXOffset, mouseYOffset, yaw = 0.0f, pitch = 0.0f;
GLfloat zOffset = 0.0f;
GLfloat sensitivity = 0.005f;
bool isPerspective = true;


int buttonUsed, ButtonState;

glm::vec3 CameraPosition = glm::vec3(0.0f,0.0f,5.0f);
glm::vec3 CameraUpY = glm::vec3(0.0f,1.0f,0.0f);
glm::vec3 CameraForwardZ = glm::vec3(0.0f,0.0f, -1.0f);
glm::vec3 front;
glm::vec3 offset = glm::vec3(0.0f,0.0f,0.0f);

SpoonPointImporter* svl;

struct Light {
	glm::vec3 position;
	glm::vec3 color;
} gLight;

void UResizeWindow(int, int);
void URenderGraphics(void);
void UCreateShaders(void);
void UCreateBuffers(void);
void UGenerateTexture(void);

void UMouseClick(int button, int state, int x, int y);
void UMousePressedMove(int x, int y);
void UMouseMove(int x, int y);
void UKeyboardRelease(unsigned char key, GLint x, GLint y);
void UKeyboardPress(unsigned char key, GLint x, GLint y);
float clmp(float,float,float);

const GLchar * vertexShaderSource = GLSL(330,
		layout(location=0) in vec3 position; // Recieve vertex coordinates from attribute 0
		layout(location=1) in vec3 normalCoordinates;
		layout(location=2) in vec2 textureCoordinates;


		out vec3 pos;
		out vec3 normals;
		out vec2 mobileTextureCoordinate;


		uniform mat4 model;
		uniform mat4 view;
		uniform mat4 projection;
			void main(){
				pos = vec3(model * vec4(position, 1.0f));
				normals =  mat3(transpose(inverse(model))) * normalCoordinates;
				mobileTextureCoordinate = vec2(textureCoordinates.x, 1.0f - textureCoordinates.y);


				gl_Position = projection * view * model* vec4(position, 1.0f); // Send the position to gl_position.

			}
		);

const GLchar * fragmentShaderSource = GLSL(330,

				in vec3 pos;
				in vec3 normals;
				in vec2 mobileTextureCoordinate;

				out vec4 gpuTexture;

				uniform sampler2D uTexture;
				uniform vec3 Lposition;
				uniform vec3 Lcolor;
				uniform vec3 viewPos;

					void main(){
						float ambientStrength = 0.1f;
						vec3 ambient = ambientStrength * Lcolor; // generate ambient light color


						vec3 norm = normalize(normals); //Normalize vectors
						vec3 LightDirection = normalize(Lposition - pos);
						float impact = max(dot(norm, LightDirection),0.0);
						vec3 diffuse = impact * Lcolor;

						//Calculate Specular lighting
						float specularIntensity = 0.8f;
						float highlightSize = 16.0f;
						vec3 viewDir = normalize(viewPos - pos);
						vec3 reflectDir = reflect(-LightDirection, norm);
						//Calculate specular component
						float specularComponent = pow(max(dot(viewDir, reflectDir), 0.0), highlightSize);
						vec3 specular = specularIntensity * specularComponent * Lcolor;



						vec4 surfaceColor = texture(uTexture,mobileTextureCoordinate);

						vec3 phong = (ambient + diffuse + specular) * surfaceColor.rgb;
						gpuTexture = vec4(Lcolor * phong.rgb, surfaceColor.a); // Send the texture to the GPU
						//gpuTexture = texture(uTexture,mobileTextureCoordinate);
					}
				);


int main(int argc, char* argv[])
{

	svl = new std::SpoonPointImporter();
	// Initializes freeglut
	glutInit(&argc, argv);
	gLight.position = glm::vec3(0.0f,0.0f,5.0f);
	gLight.color = glm::vec3(1.0f,1.0f,1.0f);
	// memory buffer setup for display
	glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGBA);

	// set the window size
	glutInitWindowSize(WindowWidth, WindowHeight);

	// Create a window with the macro placeholder title
	glutCreateWindow(WINDOW_TITLE);

	glutReshapeFunc(UResizeWindow); // called when resizing the window

	glewExperimental = GL_TRUE;

	if (glewInit() != GLEW_OK)
	{
		std::cout << "Failed to initialize GLEW" << std::endl;
		return -1;
	}


	front.x = 10.0f * cos(yaw);
	front.y = 10.0f * sin(pitch);
	front.z = sin(yaw) * cos(pitch) * 10.0f + zOffset;

	UGenerateTexture();
	UCreateShaders();

	UCreateBuffers();

	glUseProgram(shaderProgram);
	//sets the background color of the window to clack. Optional.
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

	glutDisplayFunc(URenderGraphics); // Render graphics on the screen.
	glutMouseFunc(UMouseClick);
	glutPassiveMotionFunc(UMouseMove);
	glutMotionFunc(UMousePressedMove);
	glutKeyboardUpFunc(UKeyboardRelease);
	glutKeyboardFunc(UKeyboardPress);
	glutMainLoop();

	glDeleteVertexArrays(1, &VAO);
	glDeleteBuffers(1, &VBO);
	glDeleteBuffers(1, &EBO);

	delete svl;
	return 0;
}



void UResizeWindow(int Width, int Height)
{
	WindowWidth = Width;
	WindowHeight = Height;
	glViewport(0, 0, WindowWidth, WindowHeight);
}

void URenderGraphics(void)
{
	glEnable(GL_DEPTH_TEST); //Enable z-Depth
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); //Clear the screen


	glUseProgram(shaderProgram);
	glBindVertexArray(VAO); //Activate the array before transforming

	CameraForwardZ = front;
	//change the model
	glm::mat4 model;

	model = glm::translate(model, glm::vec3(0.0f,0.0f,5.0f));

	model = glm::rotate(model, 45.0f, glm::vec3(0,1.0f,0));


	model = glm::scale(model, glm::vec3(1.0f,1.0f,1.0f));

	//Move the camera
	glm::mat4 view;

	view = glm::lookAt(CameraForwardZ, glm::vec3(3.0f,0.0f,0.0f), CameraUpY);

	gLight.position = front;
	//Make the perspective
	glm::mat4 projection;

	if(isPerspective){
		projection = glm::perspective(45.0f, (GLfloat)WindowWidth / (GLfloat)WindowHeight, 0.1f, 100.0f);
	}
	else{
		projection = glm::ortho(-5.0f, 5.0f, -5.0f, 5.0f, 0.1f, 100.0f);
		//Note: wasn't able to get this to display the spoon at all, not sure what I did wrong though.
	}
	// pass the matrices to the shader program.
	GLuint modelLoc = glGetUniformLocation(shaderProgram, "model");
	GLuint viewLoc = glGetUniformLocation(shaderProgram, "view");
	GLuint projLoc = glGetUniformLocation(shaderProgram, "projection");

	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
	glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
	glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

	GLint lightColorLoc, lightPositionLoc;
	lightColorLoc =  glGetUniformLocation(shaderProgram, "Lcolor");
	lightPositionLoc =  glGetUniformLocation(shaderProgram, "Lposition");

	glUniform3f(lightColorLoc, gLight.color.r, gLight.color.g, gLight.color.b);
	glUniform3f(lightPositionLoc, gLight.position.x, gLight.position.y, gLight.position.z);

	glBindTexture(GL_TEXTURE_2D, texture);
	//Draw the triangles
	glDrawElements(GL_TRIANGLES, 300, GL_UNSIGNED_INT, 0); // Draw the triangle using indices


	glBindVertexArray(0); //Deactivate the Vertex Array Object;

	glutPostRedisplay();
	glutSwapBuffers(); //Flip the back buffer with the front buffer each frame. Like GL Flush.
}

void UCreateShaders(void){

	//Vertex Shader
	GLint vertexShader = glCreateShader(GL_VERTEX_SHADER); //Create the Vertex Shader
	glShaderSource(vertexShader, 1, &vertexShaderSource, NULL); //Attach it
	glCompileShader(vertexShader); // Compile it

	//Fragment Shader
	GLint fragmentShader = glCreateShader(GL_FRAGMENT_SHADER); //Create the Fragment Shader
	glShaderSource(fragmentShader, 1, &fragmentShaderSource, NULL); //Attach it.
	glCompileShader(fragmentShader); //Compile it.

	//Shader program
	shaderProgram = glCreateProgram(); //Create the shader program
	glAttachShader(shaderProgram, vertexShader); //attach the vertex shader
	glAttachShader(shaderProgram, fragmentShader); // attach the fragment shader
	glLinkProgram(shaderProgram); // Link them to the shader

	//Delete the Vertex and Fragment shaders.
	glDeleteShader(vertexShader);
	glDeleteShader(fragmentShader);

}
void UCreateBuffers(){

	GLfloat * tempVertex = svl->convertVertexToFloats();
	GLfloat vertices[376];
	memcpy(vertices, tempVertex, sizeof(vertices));
	GLuint * tempTriangles = svl->convertTrianglesToInts();
	GLuint indices[270];
	memcpy(indices, tempTriangles, sizeof(indices));
	//Strange as this may look, this is necessary in order to get the right format for the function in the end.


	//Generate ids
		glGenVertexArrays(1, &VAO);
		glGenBuffers(1, &VBO);
		glGenBuffers(1, &EBO);

		//Activate the array
		glBindVertexArray(VAO);

		//Activate the VBOr
		glBindBuffer(GL_ARRAY_BUFFER, VBO);
		glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);


		//Activate the element buffer
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
		glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

		//Set Attribute pointer 0 to position data
		glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (GLvoid*)0);
		glEnableVertexAttribArray(0);

		//Set attribute pointer 1 to normal data
		glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (GLvoid*)(3 * sizeof(GLfloat)));
		glEnableVertexAttribArray(1);

		//Set attribute pointer 2 to texture data
		glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(GLfloat), (GLvoid*)(3 * sizeof(GLfloat)));
		glEnableVertexAttribArray(2);

		glBindVertexArray(0);
}
void UGenerateTexture(){

	glGenTextures(1, &texture);
	glBindTexture(GL_TEXTURE_2D, texture);

	int width, height;

	unsigned char* image = SOIL_load_image("metal.jpg", &width, &height, 0, SOIL_LOAD_RGB);

	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);

	glGenerateMipmap(GL_TEXTURE_2D);
	SOIL_free_image_data(image);
	glBindTexture(GL_TEXTURE_2D, 0);
}

void UMouseClick(int button, int state, int x, int y){
	buttonUsed = button; //Save the button used and the button state
	ButtonState = state;
}
//This function only triggers when a mouse button is held down
void UMousePressedMove(int x, int y){
	mod_key = glutGetModifiers(); //get what assisting keys are held down, in this case, we want the alt key.

	//Set the offsets and old mouse locations, we do this in both functions, because we always want the old position known
	mouseXOffset = x - lastMouseX;
	mouseYOffset = lastMouseY - y;

	lastMouseX = x;
	lastMouseY = y;


		if(mod_key == GLUT_ACTIVE_ALT){
			if(ButtonState == GLUT_DOWN){
				if(buttonUsed == GLUT_LEFT_BUTTON){ //If ALT+LeftMouse button is held down, rotate the camera
					mouseXOffset *= sensitivity;
					mouseYOffset *= sensitivity;

					yaw += mouseXOffset;
					pitch += mouseYOffset;

					front.x = clmp(10.0f * cos(yaw),-90.0f, 90.0f) + offset.x;
					front.y = clmp(10.0f * sin(pitch),-90.0f, 90.0f) + offset.y;
					front.z = clmp(sin(yaw) * cos(pitch) * 10.0f + zOffset,-90.0f, 90.0f) + offset.z;
				}
				else if(buttonUsed == GLUT_RIGHT_BUTTON){ //If ALT+RightMouse button is held down, zoom.
					mouseXOffset *= sensitivity;
					mouseYOffset *= sensitivity;
					zOffset += mouseYOffset;
					front.z += mouseYOffset;

				}
			}
		}
}

void UMouseMove(int x, int y){
	//Set the offsets and old mouse locations, we do this in both functions, because we always want the old position known
	mouseXOffset = x - lastMouseX;
	mouseYOffset = lastMouseY - y;

	lastMouseX = x;
	lastMouseY = y;

}
void UKeyboardRelease(unsigned char key, GLint x, GLint y){
	if(key == 'v'){
		isPerspective = !isPerspective;
	}
	if(key == '+'){
		gLight.color = glm::vec3(clmp(gLight.color.r + 0.1f, 0, 1), clmp(gLight.color.g + 0.1f, 0, 1), clmp(gLight.color.b + 0.1f, 0, 1));
	}
	if(key == '-'){
		gLight.color = glm::vec3(clmp(gLight.color.r - 0.1f, 0, 1), clmp(gLight.color.g - 0.1f, 0, 1), clmp(gLight.color.b - 0.1f, 0, 1));
	}
	if(key == '1'){
		gLight.color = glm::vec3(1, 1, 1);
	}
	if(key == '2'){
		gLight.color = glm::vec3(1,0,0);
	}
	if(key == '3'){
		gLight.color = glm::vec3(0, 1, 0);
	}
	if(key == '4'){
		gLight.color = glm::vec3(0,0, 1);
	}
}
void UKeyboardPress(unsigned char key, GLint x, GLint y){
	if(key == 'a'){
		offset.x -= 1.0f;
	}
	else if(key == 'd'){
		offset.x += 1.0f;
	}
	if(key == 'w'){
			offset.y -= 1.0f;
	}
	else if(key == 's'){
		offset.y += 1.0f;
	}

	front.x = clmp(10.0f * cos(yaw),-90.0f, 90.0f) + offset.x;
	front.y = clmp(10.0f * sin(pitch),-90.0f, 90.0f) + offset.y;
	front.z = clmp(sin(yaw) * cos(pitch) * 10.0f + zOffset,-90.0f, 90.0f) + offset.z;
}
float clmp(float n,  float bottom, float top){
	return std::max(bottom, std::min(n, top));

}
