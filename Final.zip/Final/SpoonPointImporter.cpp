
#include "SpoonPointImporter.h"

namespace std {
	//Create the vertex list
	void SpoonPointImporter::createVertexList(){
		ifstream infile("AllVertexes.txt");
		fullVertexList = new vector<float>[376]();
		//Currently hard-coded, but I plan to fix this in the future.
		string line;
		while(getline(infile, line)){
			//Go through the text file line by line
			stringstream ss(line);
			string item;
			while (std::getline(ss, item, ',')) { //Split the text file on commas
				fullVertexList->push_back(atof(item.c_str())); //Add it to the vertex list.
			}
		}
	}
	void SpoonPointImporter::createTriangleList(){
		ifstream infile("AllTriangles.txt");
		fullTriangleList = new vector<unsigned int>[270]();
		//Currently hard-coded, but i plan to fix this in the future.
		string line;
		while(getline(infile, line)){
			//Go through the text file line by line
			stringstream ss(line);
			string item;
			while (std::getline(ss, item, ',')) { //Split the line on commas
				fullTriangleList->push_back(atoi(item.c_str())); //Add it to the triangle list.
			}
		}
	}
	float* SpoonPointImporter::convertVertexToFloats(){
		vector<float> convList = *fullVertexList;
		//This is done in order to change it from a pointer.
		return &convList[0];
	}
	unsigned int* SpoonPointImporter::convertTrianglesToInts(){
		vector<unsigned int> convList = *fullTriangleList;
		return &convList[0];
	}
	SpoonPointImporter::SpoonPointImporter() {

		createVertexList();
		createTriangleList();
	}
	SpoonPointImporter::~SpoonPointImporter() {
	}
}/* namespace std */
