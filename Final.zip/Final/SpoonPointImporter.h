
#include <fstream>
#include <sstream>
#include <string>
#include <algorithm>
#include <cstdlib>
#include <vector>

#ifndef SPOONVERTEXLIST_H_
#define SPOONVERTEXLIST_H_

namespace std {

class SpoonPointImporter {
public:
	SpoonPointImporter();
	virtual ~SpoonPointImporter();
	int fullCount;
	vector<float> * fullVertexList;
	float* convertVertexToFloats();
	vector<unsigned int> * fullTriangleList;
	unsigned int* convertTrianglesToInts();
private:
	void createVertexList();
	void createTriangleList();
};

} /* namespace std */

#endif /* SPOONVERTEXLIST_H_ */
