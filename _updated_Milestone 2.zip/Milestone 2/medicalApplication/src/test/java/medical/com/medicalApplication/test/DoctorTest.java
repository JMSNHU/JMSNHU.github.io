package medical.com.medicalApplication.test;

import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import medical.com.medicalApplication.model.Doctor;

public class DoctorTest {
	private Doctor doctor;
	@Before
	public void before(){
		this.doctor = new Doctor("John", "1111");
	}
	@Test
	public void testSetName() {
		assertTrue(doctor.getName().equals("John"));
	}

	@Test
	public void testSetId() {
		assertTrue(doctor.getId().equals("1111"));
	}

	@Test
	public void testToString() {
		assertTrue(doctor.toString().equals("Doctor Name: John ID: 1111")); //Error missing a space after Doctor Name:
		//Note, resolved
	}
}
