package medical.com.medicalApplication.test;

import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import medical.com.medicalApplication.model.Patient;

public class PatientTest {
	private Patient patient;
	@Before
	public void before(){
		this.patient = new Patient("John", "1111");
	}
	@Test
	public void testSetName() {
		assertTrue(patient.getName().equals("John"));
	}

	@Test
	public void testSetId() {
		assertTrue(patient.getId().equals("1111"));
	}
	@Test
	public void testToString() {
		assertTrue(patient.toString().equals("Patient Name: John ID: 1111"));
	}
}
