package medical.com.medicalApplication.test;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ AllModel.class, AllServiceTests.class })
public class AllTests {

}
