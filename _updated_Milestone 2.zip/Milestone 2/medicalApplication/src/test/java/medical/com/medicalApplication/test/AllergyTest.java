package medical.com.medicalApplication.test;

import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import medical.com.medicalApplication.model.Allergy;

public class AllergyTest {
	private Allergy allergy;
	//Note: There was an error in spelling I found when I was creating the Allergy test class. The base class should be Allergy, not Allergey.
	//Although this wasn't a technical bug, it was a semantic bug, that could lead to confusion down the line, so I resolved it.
	//It was found through looking at the code as opposed to the more functional tests that these would be running.
	//All that said, this was bug number 1

	@Before
	public void before(){
		this.allergy = new Allergy("Pollen");
	}
	@Test
	public void testSetName() {
		assertTrue(allergy.getName().equals("Pollen"));
	}

	@Test
	public void testToString() {
		assertTrue(allergy.toString().equals("Allergy: Pollen")); //Error, it's missing a space after Allergy
		//Note, resolved.
	}
}
