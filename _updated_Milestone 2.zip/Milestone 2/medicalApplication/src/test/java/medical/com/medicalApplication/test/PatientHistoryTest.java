package medical.com.medicalApplication.test;

import static org.junit.Assert.assertTrue;


import org.junit.Before;
import org.junit.Test;

import medical.com.medicalApplication.model.Allergy;
import medical.com.medicalApplication.model.Medication;
import medical.com.medicalApplication.model.PatientHistory;
import medical.com.medicalApplication.model.Treatment;

public class PatientHistoryTest {

	private PatientHistory history;
	@Before
	public void before(){
		history = new PatientHistory();

		history.addAllergy(new Allergy("Pollen"));
		history.addTreatment(new Treatment("2019-05-01", "Surgery", "A surgery"));
		history.addMedication(new Medication("Drug", "2019-05-01", "2019-05-10", "1MG"));
	}

	@Test
	public void testSetAllergy() {
		
		assertTrue((history.getAlergies().stream().anyMatch(
						allergy -> allergy.getName().equals("Pollen"))));
	}

	@Test
	public void testSetMedication() {
		
		assertTrue(history.getAllMedications().stream().anyMatch(
						medication -> medication.getName().equals("Drug") 
						&& medication.getStartDate().equals("2019-05-01") 
						&& medication.getEndDate().equals("2019-05-10") 
						&& medication.getDose().equals("1MG")));
	}

	@Test
	public void testSetTreatment() {
		
		assertTrue(history.getAllTreatments().stream().anyMatch(
						treatment -> treatment.getTreatmentDate().equals("2019-05-01") 
						&& treatment.getDiagnose().equals("Surgery") 
						&& treatment.getDescription().equals("A surgery")));
	}
}
