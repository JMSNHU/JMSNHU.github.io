package medical.com.medicalApplication.test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import medical.com.medicalApplication.services.DoctorService;

public class DoctorServiceTest {
	@Before
	public void setUp() throws Exception {
		DoctorService.getReference().addDoctor("Mike", "1234");
	}
	
	@Test
	public void testCreateDoctor() {
		assertTrue(DoctorService.getReference().getAllDoctors().stream().allMatch(doc -> doc.getId().equals("1234") 
				&& doc.getName().equals("Mike")));
	}
	@Test
	public void testCreateDuplicateDoctor() {
		assertFalse(DoctorService.getReference().addDoctor("Mike", "1234"));
		//Error, was able to add a duplicate doctor.
		//Note, resolved by changing the == to a .equals()
	}
	
}
