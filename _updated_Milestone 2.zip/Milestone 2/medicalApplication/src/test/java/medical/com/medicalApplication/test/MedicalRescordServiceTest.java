package medical.com.medicalApplication.test;

import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import medical.com.medicalApplication.model.Allergy;
import medical.com.medicalApplication.model.MedicalRecord;
import medical.com.medicalApplication.model.Medication;
import medical.com.medicalApplication.model.Patient;
import medical.com.medicalApplication.model.Treatment;
import medical.com.medicalApplication.services.MedicalRescordService;
public class MedicalRescordServiceTest {
	private Patient patient;
	private MedicalRecord record;
	@Before
	public void setUp() throws Exception {
		
		//create a Patient
		MedicalRescordService.getReference().addPatient("Mike", "1234");
		
		//Get the patient from the system
		patient = MedicalRescordService.getReference().getPatient("1234");
		
		//Get it's record
		record = MedicalRescordService.getReference().getMedicalRecord("1234");

		//Add history.
		record.getHistory().addAllergy(new Allergy("Pollen"));
		record.getHistory().addTreatment(new Treatment("2019-05-01", "Surgery", "A surgery"));
		record.getHistory().addMedication(new Medication("Drug", "2019-05-01", "2019-05-10", "1MG"));
		
		
	}
	
	@Test
	public void testCreatePatient() {
		//check that the patient that was previously pulled exists.
		assertTrue(patient.getName().equals("Mike") && patient.getId().equals("1234"));
	}
	@Test
	public void testCreateMedicalRecord() {
		//check that the medical record matches
		assertTrue(record.getPatient().getName().equals(patient.getName()));
	}
	@Test
	public void testFindPatientsWithAllergy() {
		//Check for the patient in the list of people with a Pollen allergies.
		assertTrue(MedicalRescordService.getReference().getPatientsWithAllergies("Pollen").contains(patient));
	}
	@Test
	public void testFindSpecificAllergy() {
		assertTrue(MedicalRescordService.getReference().GetAllAllergies().stream().anyMatch(allergy -> allergy.getName().equals("Pollen")));
	}
}
