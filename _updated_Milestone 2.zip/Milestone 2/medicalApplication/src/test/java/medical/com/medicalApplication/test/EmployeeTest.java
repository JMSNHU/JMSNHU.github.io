package medical.com.medicalApplication.test;

import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import medical.com.medicalApplication.model.Employee;

public class EmployeeTest {
	private Employee employee;
	@Before
	public void before(){
		this.employee = new Employee("John", "1111");
		employee.setPassword("password");
	}
	@Test
	public void testSetName() {
		assertTrue(employee.getName().equals("John"));
	}

	@Test
	public void testSetId() {
		assertTrue(employee.getId().equals("1111"));
	}
	@Test
	public void testSetPassword() {
		assertTrue(employee.getPassword().equals("password"));
		//Note: error here, password is hardcoded, and there is no way to set it, flagging it as a test error
		//Created a function to setPassword, resolved.
	}	
}
