package medical.com.medicalApplication.test;

import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import medical.com.medicalApplication.model.Medication;


public class MedicationTest {
	private Medication medication;
	@Before
	public void before(){
		this.medication = new Medication("Drug", "2019-05-01", "2019-05-10", "1MG");
		
	}
	@Test
	public void testSetName() {
		assertTrue(medication.getName().equals("Drug"));
	}

	@Test
	public void testSetStart() {
		assertTrue(medication.getStartDate().equals("2019-05-01"));
	}
	@Test
	public void testSetEnd() {
		assertTrue(medication.getEndDate().equals("2019-05-10"));
	}

	@Test
	public void testSetDose() {
		assertTrue(medication.getDose().equals("1MG"));
	}
	@Test
	public void testToString() {
		assertTrue(medication.toString().equals("Medication: Drug Start Date: 2019-05-01 End Date: 2019-05-10 Dose: 1MG"));  //Error missing a space after Medication:
		//Note, resolved.
	}
}
