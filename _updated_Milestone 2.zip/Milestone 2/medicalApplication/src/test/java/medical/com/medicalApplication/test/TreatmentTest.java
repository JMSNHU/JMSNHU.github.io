package medical.com.medicalApplication.test;

import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import medical.com.medicalApplication.model.Treatment;

/**
 * 
 * This class represents a treatment model in the system.
 *
 */
public class TreatmentTest {
	private Treatment treatment;
	@Before
	public void before(){
		this.treatment = new Treatment("2019-05-01", "Surgery", "A surgery");
	}
	@Test
	public void testSetName() {
		assertTrue(treatment.getTreatmentDate().equals("2019-05-01"));
	}

	@Test
	public void testSetDiagnose() {
		assertTrue(treatment.getDiagnose().equals("Surgery"));
	}

	@Test
	public void testSetDescription() {
		assertTrue(treatment.getDescription().equals("A surgery"));
	}
	@Test
	public void testToString() {
		assertTrue(treatment.toString().equals("Treatment: "+ " Date: "+ treatment.getTreatmentDate()+ " Diagnose: " + treatment.getDiagnose() +" Surgery Description: "+treatment.getDescription()));
		//To string function has an error, it's missing the description.
		//Note, resolved.
	}

}
