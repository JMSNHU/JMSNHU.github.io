package medical.com.medicalApplication.test;

import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import medical.com.medicalApplication.model.Allergy;
import medical.com.medicalApplication.model.MedicalRecord;
import medical.com.medicalApplication.model.Medication;
import medical.com.medicalApplication.model.Patient;
import medical.com.medicalApplication.model.PatientHistory;
import medical.com.medicalApplication.model.Treatment;

public class MedicalRecordTest {
	private MedicalRecord record;
	@Before
	public void before(){
		Patient patient = new Patient("John", "1111");
		this.record = new MedicalRecord(patient);
		record.getHistory().addAllergy(new Allergy("Pollen"));
		record.getHistory().addTreatment(new Treatment("2019-05-01", "Surgery", "A surgery"));
		record.getHistory().addMedication(new Medication("Drug", "2019-05-01", "2019-05-10", "1MG"));
	}
	@Test
	public void testSetPatient() {
		
		Patient temp = record.getPatient();
		
		assertTrue(temp.getName().equals("John") && temp.getId().equals("1111"));
	}

	@Test
	public void testSetRecord() {
		
		PatientHistory history = record.getHistory();
		
		assertTrue(
				(history.getAlergies().stream().anyMatch(
						allergy -> allergy.getName().equals("Pollen")))
				&&
				(history.getAllMedications().stream().allMatch(
						medication -> medication.getName().equals("Drug") 
						&& medication.getStartDate().equals("2019-05-01") 
						&& medication.getEndDate().equals("2019-05-10") 
						&& medication.getDose().equals("1MG")))
				&&
				(history.getAllTreatments().stream().allMatch(
						treatment -> treatment.getTreatmentDate().equals("2019-05-01") 
						&& treatment.getDiagnose().equals("Surgery") 
						&& treatment.getDescription().equals("A surgery")))
				
				);
	}
	
	
}
