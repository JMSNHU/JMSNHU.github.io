#!/usr/bin/python
import json
from bson import json_util 
import bottle
from bottle import route, run, request, abort
import datetime
from pymongo import MongoClient
import numbers
import decimal


#Final

#This method is used to create a stock using Post
@route('/stocks/api/v1.0/createStock/<ticker>', method='POST')
def post_create(ticker):
  if ticker=="": #confirm that the ticker is there
    return json.loads(json.dumps("INVALID DATA", indent=4, default=json_util.default))
  identifier = dict({"Ticker":ticker})
  json_text = dict(request.json) #get the JSON data.
  if json_text.has_key("Ticker") == False:
    json_text["Ticker"] = ticker #If it has no Ticker, add the ticker that was pulled
  result = insert_document(json_text)
  method_output = str(result) +"\n" #return the result.
  return json.loads(json.dumps(method_output, indent=4, default=json_util.default)) #send it to the website.

#this method returns the stockReport using Post
@route('/stocks/api/v1.0/stockReport', method='POST')
def post_stock():
  
  json_text = dict(request.json) #Pull the JSON data
  result = get_stock_report(json_text)
  method_output = ""
  for split_results in result:
    method_output += str(split_results) +"\n" #split the output into something we can send to the user
  return json.loads(json.dumps(method_output, indent=4, default=json_util.default)) #send it.

#Get a stock based on a ticker using Get
@route('/stocks/api/v1.0/getStock/<ticker>', method='GET')
def get_read(ticker):
  if ticker=="": #confirm it has a ticker
    return json.loads(json.dumps("INVALID DATA", indent=4, default=json_util.default))
  identifier = dict({"Ticker":ticker}) #Turn the ticker it a KeyValue Pair
  result = read_document(identifier)
  method_output = str(result)+"\n" #convert the response to something that we can output
  return json.loads(json.dumps(method_output, indent=4, default=json_util.default)) #output
  
#Get the RangeReport using Low and High as the range using Get
@route('/stocks/api/v1.0/RangeReport', method='GET')
def get_range():
	#pull both arguments from the URL
  low = float(request.GET.get('low')) 
  high = float(request.GET.get('high'))
  result = read_cost(low, high)
  method_output = ""
  for split_results in result:
    method_output += str(split_results)+"\n"  #convert the output to something that we can use.
  return json.loads(json.dumps(method_output, indent=4, default=json_util.default)) #output.

#Get an IndustryReport using a specific industry as the argument, done through Get.
@route('/stocks/api/v1.0/industryReport/<industry>', method='GET')
def get_industry(industry):
  if industry=="": #confirm that you have an industry
    return json.loads(json.dumps("INVALID DATA", indent=4, default=json_util.default))
  result = read_top_five(industry)
  method_output = ""
  for split_results in result:
    method_output += str(split_results)+"\n" #convert the output.
  return json.loads(json.dumps(method_output, indent=4, default=json_util.default))#Output

#get a Sector report based on a sector, done through Get
@route('/stocks/api/v1.0/sectorReport/<sector>', method='GET')
def get_sector(sector):
  if sector=="": #confirm that you have a sector
    return json.loads(json.dumps("INVALID DATA", indent=4, default=json_util.default))
  result = read_shares(sector)
  method_output = ""
  for split_results in result:
    method_output += str(split_results)+"\n" #convert the output
  return json.loads(json.dumps(method_output, indent=4, default=json_util.default)) #output.

#update a record using a ticker through Put.
@route('/stocks/api/v1.0/updateStock/<ticker>', method='PUT')
def put_update(ticker):
  if ticker=="": #confirm that the ticker is there
    return json.loads(json.dumps("INVALID DATA", indent=4, default=json_util.default))
  identifier = dict({"Ticker":ticker}) #convert it to a KeyValue pair.
  json_text = dict(request.json) #get the JSON
  #confirm that it has the arguments
  if not(json_text.has_key("Volume") == True and isinstance(json_text["Volume"], numbers.Number) == True and json_text["Volume"] > 0):
    return json.loads(json.dumps("INVALID DATA", indent=4, default=json_util.default))
  result = update_document(identifier, json_text)
  
  method_output = str(result)+"\n" #convert the results
  return json.loads(json.dumps(method_output, indent=4, default=json_util.default)) #output

#delete a record using a ticker, through the Delete method.
@route('/stocks/api/v1.0/deleteStock/<ticker>', method='DELETE')
def get_delete(ticker=""):
  if ticker=="": #confirm that the ticker exists
    return json.loads(json.dumps("INVALID DATA", indent=4, default=json_util.default))
  identifier = dict({"Ticker":ticker}) #convert it to a KeyValue pair
  result = dict(delete_document(identifier))
  method_output = str(result)+"\n" #convert the results
  return json.loads(json.dumps(method_output, indent=4, default=json_util.default))#output


#MongoDB code

#a lot of these functions are straight-forward. They run a database command, if it fails, they abort.
#For the ones that aren't, I will write more detailed comments.
connection = MongoClient('localhost', 27017)
db = connection['market']
collection = db['stocks']
abortCode = 400
def insert_document(document):
  try:
    result=collection.insert_one(document)
    return True
  except ValidationError as ve:
    abort(abortCode, str(ve))
    return False
def read_document(identifier):
  try:
    result=collection.find_one(identifier)
  except ValidationError as ve:
    abort(abortCode, str(ve))
  return result
def update_document(identifier, document):
  try:
    collection.find_one_and_update(identifier, {"$set":document}, upsert=False)
  except ValidationError as ve:
    abort(abortCode, str(ve))
    return False
  return True
def delete_document(identifier):
  try:
    collection.delete_one(identifier)
  except ValidationError as ve:
    abort(abortCode, str(ve))
    return False
  return True
def get_stock_report(tickers):
  try:
  #This command pulls specific arguments, unlike the others which grab every column
    result=collection.find({"Ticker":{"$in": tickers["tickers"]}}, {"Ticker":1, "Company":1,"Performance (Week)":1})
  except ValidationError as ve:
    abort(abortCode, str(ve))
  return result
def read_top_five(industry):
  #unlike the previous ones, these next few use aggregate, so they needs to specify the pipeline.
  pipeline = [
      {"$project":{"_id":"$Ticker", "Industry":1}},
      {"$match":{"Industry":industry}},
      {"$limit":5}
    ]
	#once the pipeline is defined, we just call the aggregate method with it.
  result=collection.aggregate(pipeline)
  return result

#all of these function similar to read_top_five
def read_cost(low, high):
  pipeline = [
      {"$project":{"_id":"$Ticker", "50-Day Simple Moving Average":1}},
      {"$match":{"50-Day Simple Moving Average":{"$gt":low, "$lt":high}}},
      {"$limit":5}
    ]
  result=collection.aggregate(pipeline)
  return result

def read_shares(sector):
  pipeline = [
    {"$project":{"_id":"$Industry","Sector":1,"Shares Outstanding":1}},
      {"$match":{"Sector":sector}},
      {"$group":{"_id":"$_id", "shares":{"$sum":"$Shares Outstanding"}}},
      {"$sort": {"Shares":-1}}
    ]
  result=collection.aggregate(pipeline)
  return result




#Main run function
if __name__ == '__main__':
  #app.run(debug=True)
  run(host='localhost', port=8080,debug=False)
  
  
  